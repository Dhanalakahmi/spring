package com.example.jsonn;
import lombok.Data;

import java.util.List;
@Data
public class productList {

        private List<Product> productList;
    }



