package com.example.jsonn;

import lombok.Data;
@Data
public class Product {
        private String productId;
        private String productName;
        private String unitOfMeasure;
        private String launchDate;
    }


