package com.example.jsonn;
import com.example.jsonn.productList;
import com.example.jsonn.Product;
import com.example.jsonn.ProductService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@Slf4j
@RestController
public class productController {
    @Autowired
    private ProductService productService;

    @PostMapping("/sortProducts")
    public ResponseEntity<?> sortPro(@RequestBody productList produc) {

        List<Product> products = produc.getProductList();
        List<Product> response = productService.sortPro(products);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
