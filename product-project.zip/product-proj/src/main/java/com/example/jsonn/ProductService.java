package com.example.jsonn;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import com.example.jsonn.Product;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProductService {
    public List<Product> sortPro(List<Product> products) {
        List<Product> result = products.stream().sorted(Comparator.comparing(Product::getProductId).thenComparing(Product::getLaunchDate).reversed())
                .collect(Collectors.toList());
        return result;
    }
}
