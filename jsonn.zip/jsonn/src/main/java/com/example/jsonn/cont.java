package com.example.jsonn;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class cont {
    @RequestMapping("createProduct")
    @ResponseBody
    public void mapp()
    {
        System.out.println("Status");
 
    }

}
