package com.example.jsonn;

import org.springframework.stereotype.Component;


import java.util.ArrayList;
@Component

public class product {
    private int pid;
    private String pname;
    private String uomeasure;


    
    public int getPid() {
        return pid;
    }
    public  void addge()
    {
        System.out.println("Compiled");
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getUomeasure() {
        return uomeasure;
    }

    public void setUomeasure(String uomeasure) {
        this.uomeasure = uomeasure;
    }

}
