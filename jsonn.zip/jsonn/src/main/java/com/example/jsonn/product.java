package com.example.jsonn;

import org.springframework.stereotype.Component;


import java.util.ArrayList;
@Component

public class product {
    private int pid;
    private String pname;
    private String uomeasure;


    public product(int pid, String pname, String uomeasure) {
        super();
        this.pid = pid;
        this.pname = pname;
        this.uomeasure = uomeasure;
    }
   List<product> p;
    public product()
    {
        p=new ArrayList<>();
        p.add(new product(pid: "Prod1", pname: "Shirt",uomeasure: "Each"));
        p.add(new product(pid: "Prod2",pname: "Trouser",uomeasure: "Each"));
        p.add(new product(pid: "Prod3",pname: "Tie",uomeasure: "Each"));
    }

    public int getPid() {
        return pid;
    }
    public  void addge()
    {
        System.out.println("Compiled");
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getUomeasure() {
        return uomeasure;
    }

    public void setUomeasure(String uomeasure) {
        this.uomeasure = uomeasure;
    }

}
