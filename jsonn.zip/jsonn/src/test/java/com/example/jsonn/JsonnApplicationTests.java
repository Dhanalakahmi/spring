package com.example.jsonn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonnApplicationTests {

	@Test
	void contextLoads() {
	}

}
