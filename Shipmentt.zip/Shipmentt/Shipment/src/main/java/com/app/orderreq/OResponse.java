package com.app.orderreq;

import com.app.model.Order;
import com.app.model.Shipment;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OResponse {
    private Order order;
    private Shipment shipment;
}
