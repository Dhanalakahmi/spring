package com.app.orderreq;

import lombok.Data;

@Data
public class ORequest {
    private String orderId;
}
